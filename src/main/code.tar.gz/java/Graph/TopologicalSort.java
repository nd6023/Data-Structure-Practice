package Graph;

public class TopologicalSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TopologicalSort topologicalSort = new TopologicalSort();
		Graph<Integer> graph = new Graph(true);
		graph.addEdge(1, 3);
		
		

	}

}
